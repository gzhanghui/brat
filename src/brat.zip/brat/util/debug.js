export function warn(msg) {
  console.error(`[BScroll warn]: ${msg}`)
}