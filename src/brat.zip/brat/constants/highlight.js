const highlightSequence = ['#FF9632', '#FFCC00', '#FF9632'].join(';'); // yellow - deep orange
export const highlightSpanSequence = highlightSequence;
export const highlightArcSequence = highlightSequence;
export const highlightTextSequence = highlightSequence;
export const highlightDuration = '2s';
export const highlightMatchSequence = '#FFFF00';